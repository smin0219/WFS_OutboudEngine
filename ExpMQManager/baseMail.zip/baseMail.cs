﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Net;

using System.Data;
using System.Configuration;

using ExpMQManager.DAL;

namespace ExpMQManager
{
    public class baseMail
    {
        public static DataTable ServerInfo = null;

        public static bool isLiveParsing = true;

        public baseMail()
        {
        }

        public static Boolean mailSend(string sAddress, string Msg, string Subject)
        {

            try
            {
                string _serverIP= "";
                try
                {
                    isLiveParsing = Convert.ToBoolean(ConfigurationManager.AppSettings["IsLiveParsing"]);
                    _serverIP = ServerInfoDAC.Instance.ServerIP;

                    if (_serverIP.Equals("") || _serverIP == null)
                    {
                        _serverIP = Convert.ToString(ConfigurationManager.AppSettings["EmailServerIP"]);
                    }
                }
                catch (Exception ex)
                {
                    _serverIP = "10.3.0.71";
                }

                string sLoginUserEmail = "ePicSupport@casusa.com";  //Using account when log in
                SmtpClient smtp = new SmtpClient(_serverIP, 25);
                MailMessage m = new MailMessage();
                m.From = new MailAddress(sLoginUserEmail, "Cargo Airport Services, LLC");
                if (isLiveParsing)
                {
                    if (sAddress.IndexOf(";") > -1)
                    {
                        string[] result = sAddress.Split(';');
                        string msAddress = "";
                        for (int i = 0; i < result.Length; i++)
                        {
                            msAddress = result[i].ToString();
                            if(msAddress != null && msAddress != string.Empty)
                                m.To.Add(new MailAddress(msAddress));
                        }
                    }
                    else
                        m.To.Add(new MailAddress(sAddress));
                }
                else
                {
                    // TEST 하려고 추가했음. // email error 나네;;; 2015-09-30
                    if (sAddress.IndexOf(";") > -1)
                    {
                        string[] result = sAddress.Split(';');
                        string msAddress = "";
                        for (int i = 0; i < result.Length; i++)
                        {
                            msAddress = result[i].ToString();
                            if(msAddress != null && msAddress != string.Empty)
                                m.To.Add(new MailAddress(msAddress));
                        }
                    }
                    else
                        m.To.Add(new MailAddress(sAddress));
                }

                m.Subject = Subject;
                m.Body = Msg;
                m.IsBodyHtml = true;
                smtp.Send(m);
                //smtp.SendAsync(m,"CASUSA");
                return true;
            }
            catch (Exception ex)
            {
                MQbuildMsg.buildLog(0, ex.Message, ex.StackTrace);        //Write a log to file I/O
                return false;
            }
        }

    }
}
